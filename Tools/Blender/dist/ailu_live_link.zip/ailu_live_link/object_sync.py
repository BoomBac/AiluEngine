import time
import uuid
from contextlib import nullcontext

from . import camera_sync, identity, light_sync, material_sync, mesh_sync, protocol
from .coordinate import ObjectLocalMatrix, SplitAffineTransform, blender_to_ailu_transform

_instance_states = {}
_object_affine_helpers = set()
_INSTANCE_BATCH_SIZE = 128


def _object_value(obj, objects, affine_helpers=None):
    from . import material_bake
    parent = obj.parent if obj.parent in objects else None
    matrix = ObjectLocalMatrix(obj, parent)
    parent_guid = identity.get_guid(parent) if parent is not None else ""
    if affine_helpers is not None:
        matrix, helper_matrix = SplitAffineTransform(matrix)
        if helper_matrix is not None:
            helper = AffineParentValue(identity.get_guid(obj), helper_matrix, parent_guid)
            affine_helpers.append(helper)
            parent_guid = helper["guid"]
    position, rotation, scale = blender_to_ailu_transform(matrix)
    materials = [material_bake.material_guid(material, obj) if material else "" for material in material_bake.EvaluatedMaterials(obj)]
    return {
        "guid": identity.get_guid(obj),
        "name": obj.name_full,
        "parent_guid": parent_guid,
        "position": list(position),
        "rotation": [rotation.x, rotation.y, rotation.z, rotation.w],
        "scale": list(scale),
        "visible": obj.visible_get() and (obj.type != "MESH" or obj.visible_camera),
        "object_type": obj.type,
        "material_guids": materials,
    }


def AffineParentValue(guid, matrix, parent_guid=""):
    position, rotation, scale = blender_to_ailu_transform(matrix)
    return {"guid": str(uuid.uuid5(uuid.NAMESPACE_URL, guid + ":affine-parent")), "name": "__AiluAffine_" + guid,
            "parent_guid": parent_guid, "object_type": "EMPTY", "visible": True, "material_guids": [],
            "position": list(position), "rotation": [rotation.x, rotation.y, rotation.z, rotation.w], "scale": list(scale)}


def SendObject(obj, objects, link):
    helpers = []
    value = _object_value(obj, objects, helpers)
    guid = value["guid"]
    for helper in helpers:
        link.send_json(protocol.OBJECT_UPSERT, helper)
    link.send_json(protocol.OBJECT_UPSERT, value)
    if helpers:
        _object_affine_helpers.add(guid)
    elif guid in _object_affine_helpers:
        link.send_json(protocol.OBJECT_DELETE, {"guid": str(uuid.uuid5(uuid.NAMESPACE_URL, guid + ":affine-parent"))})
        _object_affine_helpers.discard(guid)


def full_sync(context, link):
    from . import dirty_tracker, material_bake
    session = getattr(material_bake, "ExportSession", nullcontext)
    with dirty_tracker.export_scope(context), session():
        _full_sync(context, link)


def _full_sync(context, link):
    full_start = time.perf_counter()
    diagnostic_batch = link.begin_diagnostic_batch("full_sync")
    phases = {}
    counts = {}
    scene = context.scene
    try:
        phase_start = time.perf_counter()
        objects = set(scene.objects)
        identity.repair_duplicate_guids(objects)
        phases["scene_scan"] = (time.perf_counter() - phase_start) * 1000.0

        link.send_json(protocol.FULL_SYNC_BEGIN, {"session_guid": identity.get_session_guid(scene)})
        from . import scene_sync
        scene_sync.export_scene_settings(scene, link)
        from . import world_sync
        world_sync.export_world(context, link)
        _object_affine_helpers.clear()
        phase_start = time.perf_counter()
        for obj in objects:
            SendObject(obj, objects, link)
        phases["objects"] = (time.perf_counter() - phase_start) * 1000.0

        phase_start = time.perf_counter()
        depsgraph = context.evaluated_depsgraph_get()
        direct_mesh_objects = mesh_sync.DirectMeshObjects(context, depsgraph)
        mesh_count = 0
        sent_materials = set()
        material_ms = 0.0
        for obj in objects:
            if obj in direct_mesh_objects:
                material_start = time.perf_counter()
                material_sync.send_object_materials(obj, link, sent_materials)
                material_ms += (time.perf_counter() - material_start) * 1000.0
                if mesh_sync.send_mesh(obj, depsgraph, link):
                    mesh_count += 1
            elif obj.type == "LIGHT":
                light_sync.export_light(obj, link)
            elif obj.type == "CAMERA":
                camera_sync.export_camera(obj, scene, link)
        phases["materials"] = material_ms
        phases["geometry_and_other"] = (time.perf_counter() - phase_start) * 1000.0 - material_ms
        counts = {"objects": len(objects), "meshes": mesh_count, "materials": len(sent_materials)}
        phase_start = time.perf_counter()
        sync_instances(context, link, sent_materials, full=True, phases=phases)
        phases["instances"] = (time.perf_counter() - phase_start) * 1000.0
        counts["materials_total"] = len(sent_materials)
        from . import material_bake
        flush = getattr(material_bake, "FlushMaterials", None)
        if flush:
            flush()
        link.send_json(protocol.FULL_SYNC_END, {})
    except Exception as error:
        # An incomplete snapshot must not leave the host waiting for End or prune unseen entities.
        link.disconnect()
        link.last_error = f"Full Sync failed: {error}"
        raise
    finally:
        link.end_diagnostic_batch(diagnostic_batch, (time.perf_counter() - full_start) * 1000.0, phases, counts)


def sync_object(context, obj, link, sent_materials=None, update_geometry=True, update_materials=True,
                update_data=True):
    from . import dirty_tracker
    with dirty_tracker.export_scope(context):
        scene_objects = set(context.scene.objects)
        SendObject(obj, scene_objects, link)
        if mesh_sync.IsMeshSource(obj):
            if update_materials:
                material_sync.send_object_materials(obj, link, sent_materials)
            if update_geometry and (obj.type == "MESH" or obj in mesh_sync.DirectMeshObjects(context, context.evaluated_depsgraph_get())):
                mesh_sync.send_mesh(obj, context.evaluated_depsgraph_get(), link)
        elif obj.type == "LIGHT":
            if update_data:
                light_sync.export_light(obj, link)
        elif obj.type == "CAMERA":
            if update_data:
                camera_sync.export_camera(obj, context.scene, link)


def sync_instances(context, link, sent_materials=None, changed_objects=(), full=False, phases=None,
                   update_materials=True):
    """Flatten evaluated mesh instances using stable identities and their final world transforms."""
    from . import dirty_tracker
    with dirty_tracker.export_scope(context):
        depsgraph = context.evaluated_depsgraph_get()
        session_guid = identity.get_session_guid(context.scene)
        changed_guids = {identity.get_guid(obj) for obj in changed_objects}
        groups = {}
        affine_helpers = {}
        prototype_objects = {}
        mesh_changed_guids = set()
        current = {}
        # DepsgraphObjectInstance RNA wrappers expire when the iterator advances; snapshot values now.
        for instance in depsgraph.object_instances:
            if not instance.is_instance or instance.object.type != "MESH":
                continue
            obj = instance.object.original
            source_guid = identity.get_guid(obj)
            prototype_objects[source_guid] = obj
            parent_guid = identity.get_guid(instance.parent.original) if instance.parent else ""
            instance_key = session_guid + ":" + parent_guid + ":" + source_guid + ":" + str(tuple(instance.persistent_id))
            guid = str(uuid.uuid5(uuid.NAMESPACE_URL, instance_key))
            child_matrix, helper_matrix = SplitAffineTransform(instance.matrix_world.copy())
            position, rotation, scale = blender_to_ailu_transform(child_matrix)
            helper_guid = str(uuid.uuid5(uuid.NAMESPACE_URL, guid + ":affine-parent")) if helper_matrix is not None else ""
            helper_state = None
            if helper_matrix is not None:
                helper_position, helper_rotation, helper_scale = blender_to_ailu_transform(helper_matrix)
                helper_state = (tuple(helper_position), tuple(helper_rotation), tuple(helper_scale))
                affine_helpers[guid] = AffineParentValue(guid, helper_matrix)
            value = _object_value(obj, set())
            value.update(
                guid=guid,
                name=obj.name_full + " [Instance]",
                parent_guid=helper_guid,
                visible=instance.show_self and obj.visible_camera,
                position=list(position),
                rotation=[rotation.x, rotation.y, rotation.z, rotation.w],
                scale=list(scale),
            )
            state = (
                tuple(value["position"]),
                tuple(value["rotation"]),
                tuple(value["scale"]),
                tuple(value["material_guids"]),
                value["visible"],
                helper_state,
            )
            current[guid] = state
            previous = _instance_states.get(guid)
            mesh_changed = full or previous is None or source_guid in changed_guids
            if mesh_changed or state != previous:
                groups.setdefault(source_guid, []).append(value)
            if mesh_changed:
                mesh_changed_guids.add(source_guid)
        sent_materials = set() if sent_materials is None else sent_materials
        material_ms = 0.0
        source_objects = {identity.get_guid(obj): obj for obj in mesh_sync.DirectMeshObjects(context, depsgraph)}
        for source_guid, instances in groups.items():
            source_obj = prototype_objects.get(source_guid)
            is_external_prototype = source_guid not in source_objects
            if is_external_prototype and source_guid in mesh_changed_guids:
                mesh_sync.send_mesh(source_obj, depsgraph, link, prototype=True)
            if source_obj is None or not mesh_sync.has_geometry(source_guid):
                for instance in instances:
                    current.pop(instance["guid"], None)
                continue
            if update_materials:
                material_start = time.perf_counter()
                material_sync.send_object_materials(source_obj, link, sent_materials)
                material_ms += (time.perf_counter() - material_start) * 1000.0
            for instance in instances:
                if instance["guid"] in affine_helpers:
                    link.send_json(protocol.OBJECT_UPSERT, affine_helpers[instance["guid"]])
            for start in range(0, len(instances), _INSTANCE_BATCH_SIZE):
                link.send_json(protocol.INSTANCE_BATCH_UPSERT, {
                    "prototype_guid": source_guid,
                    "instances": instances[start:start + _INSTANCE_BATCH_SIZE],
                })
        if not full:
            for guid in _instance_states.keys() - current.keys():
                link.send_json(protocol.OBJECT_DELETE, {"guid": guid})
            for guid, previous in _instance_states.items():
                if previous[-1] is not None and (guid not in current or current[guid][-1] is None):
                    link.send_json(protocol.OBJECT_DELETE, {"guid": str(uuid.uuid5(uuid.NAMESPACE_URL, guid + ":affine-parent"))})
        _instance_states.clear()
        _instance_states.update(current)
        if phases is not None:
            phases["instance_materials"] = material_ms
