#pragma once
#ifndef __IRUNTIME_MODULE_H__
#define __IRUNTIME_MODULE_H__
#include "Framework/Core/CoreMinimal.h"

namespace Ailu
{
	class AILU_API IRuntimeModule
	{
	public:
		virtual ~IRuntimeModule() = default;
		virtual int Initialize() = 0;
		virtual void Finalize() = 0;
		virtual void Tick(f32 delta_time) = 0;
	};
}

#endif // !__IRUNTIME_MODULE_H__
